## [4.11.0] - 2023-05-16
### Fixed
- Aggregate testresults crash. [Trello 489](https://trello.com/c/IQ7ksCA8/489-tinder-swift-eyesimages-exception-type-excbadaccess-sigsegv)

## [4.10.1] - 2021-01-05
### Added
- EyesImages goes to Cocoapods as xcframework instead of 'fat' framework. [Trello 2382](https://trello.com/c/e6Q7RC5O)

## [4.10.0] - 2020-12-08
### Added
- CheckRegion via fluent interface. [Trello 2278](https://trello.com/c/iyXCgIRJ)
- Full-coverage report event. [Trello 2019](https://trello.com/c/3y4UcfXd)
- ClassicRunner to follow class structure like in other SDKs. [Trello 2175](https://trello.com/c/uWNlZxVN)
- Regression test scheme and release event. [Trello 1797](https://trello.com/c/dj7njVl4)
- Unit tests for Start session.[Trello 1849](https://trello.com/c/cYLuIO2f)
- Cache status bar height and its visibility state. [Trello 1880](https://trello.com/c/tAtvGndy)
### Updated
- DefaultMatchTimout set to 0(to avoid retry mechanism, that sometimes work incorrectly). [Trello 2273](https://trello.com/c/LudBDx1A)
- AUTO_APP_NAME method in Feature class for Swift. [Trello 2275](https://trello.com/c/jYoJSB8V)
- Retry algorithm - if current screenshot is the same as the lastscreenshot, don't upload the new screenshot to the server. [Trello 1866](https://trello.com/c/KyxkI6Bu)
- Improve long running tasks polling delay. [Trello 1877](https://trello.com/c/bs4rLwqj) 
- Replace taking rendering info after session was created. [Trello 1876](https://trello.com/c/xgkM2yHr)
### Fixed
- Full coverage report always sends tests to 'result' endpoint. [Trello 2281](https://trello.com/c/ic0fxK2w)
- hostingAppInfo and osInfo handling. [Trello 2267](https://trello.com/c/Imp4p2g1)
- Viewport size should not store float values. [Trello 2256](https://trello.com/c/lMbYayfD/)
- Test result URL in logs. [Trello 2229](https://trello.com/c/2BWdzoj6)
- Return application name, taken from bundle, if hostingAppInfo wasn't set by user. [Trello 2244](https://trello.com/c/9abe8w3O)
- hostApp value proper handling. [Trello 2239](https://trello.com/c/A9xKsgnn)
- Add feature flag AUTO_APP_NAME. [Trello 1630](https://trello.com/c/eHoL0vBg)
- x, y, width and height of any region, that is supposed to be sent to the server(ignored, strict, content, layout etc.), should be rounded. [Trello 1917](https://trello.com/c/tt860YLU)
- Configuration should be copied in setter and return copy in getter instead of using reference. [Trello 2169](https://trello.com/c/XsYCJl5G)
- Release event: create stage for each SDK, send release mail to release.reports@applitools.com. [Trello 1973](https://trello.com/c/7rEnph5U)
- Ignore/content/layout/strict/floating/accessibility regions, those were hardcoded, should be adjusted by status bar's height. [Trello 1826](https://trello.com/c/RROgFEev)

## [4.9.0] - 2020-05-19
### Added
- Accessiblity guidelines version support. [Trello 1767](https://trello.com/c/gq69woeK)
- Send report about test results either test failed or passed. [Trello 1733](https://trello.com/c/Yz6EkCqz)

## [4.8.1] - 2020-04-09
### Fixed 
- Update handling auth challenges in network requests. [Trello 1725](https://trello.com/c/UqYhOCDY)

### Added
- Update handling 'isNew' flag in StartSession request. [Trello 1715](https://trello.com/c/DcVzWbeR)
- Send agentId as custom header in all requests to Eyes server. [Trello 1697](https://trello.com/c/CzhUxOqE)

## [4.8.0] - 2020-03-27
### Fixed 
- Values of "parentBranchName" and "baselineBranchName" fields. [Trello 1688](https://trello.com/c/dDxGxser)

## [4.7.1] - 2020-03-19
### Fixed
-  bathInfo value of configuration field in EyesBase. [Trello 1666](https://trello.com/c/K51yYR7U)

## [4.7.0] - 2020-02-25
### Added
- EyesRunner and Batch notification API. [Trello 1454](https://trello.com/c/M9MWNhTH)

## [4.6.2] - 2020-02-18
### Added
- Missing fields of ImageMatchSettgins: splitBottomHeight, splitTopHeight, remainder and scale. [https://trello.com/c/T9M2UAqo/1571-add-missing-fields-to-imagematchsettings-ios]

## [4.6.1] - 2020-02-05
### Fixed
- DefaultMatchSettings are overridden properly by ImageMatchSettings. [https://trello.com/c/KEbWXavV/1495-all-sdks-defaultmatchsettings-being-overridden-incorrectly-by-imagematchsettings?menu=filter&filter=due:notdue]

## [4.6.0] - 2020-01-30
### Added
- Long-running task protocol for all request to Eyes server. [https://trello.com/c/GThsXbIL/1516-all-sdks-correctly-implement-long-running-tasks?menu=filter&filter=due:notdue]

## [4.5.0] - 2020-01-23
### Added
- Upload images directly to storage service. [https://trello.com/c/S3vZOlBD/1496-all-ios-sdks-should-upload-images-directly-to-azure-storage]

## [4.4.1] - 2019-12-20
### Added
- License info at the top of public headers
### Fixed
- Timeout for network requests is 5 minutes.
### Added
- Log message of actual path where debug screenshots are saved(if flag saveDebugScreenshots is set to true)
### Fixed 
- Nullability warnings
### Added
- "Accept" HTTP header with value "application/json"
### Fixed
- Work with regions those got floating x,, y, width and height values
### Added
- Support of APPLITOOLS_SERVER_URL environment
- Support of all existent environment variables with "bamboo_" prefix

## [4.4.0] - 2019-11-5
### Added
- Configuration API.
### Added
- CHANGELOG file for EyesImages SDK.
.
