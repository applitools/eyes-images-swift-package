// Licensed under the Applitools SDK License, which can be found here: https://www.applitools.com/eula/sdk

#import <UIKit/UIKit.h>

//! Project version number for EyesImages.
FOUNDATION_EXPORT double EyesImagesVersionNumber;

//! Project version string for EyesImages.
FOUNDATION_EXPORT const unsigned char EyesImagesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EyesImages/PublicHeader.h>

#import <EyesImages/AccessibilityRegionByRectangle.h>
#import <EyesImages/AccessibilityRegionType.h>
#import <EyesImages/ActualAppOutput.h>
#import <EyesImages/Annotations.h>
#import <EyesImages/AppEnvironment.h>
#import <EyesImages/AppOutput.h>
#import <EyesImages/BatchInfo.h>
#import <EyesImages/Branch.h>
#import <EyesImages/CheckSettings.h>
#import <EyesImages/ClassicRunner.h>
#import <EyesImages/ConfigurationBase.h>
#import <EyesImages/DebugScreenshotsProvider.h>
#import <EyesImages/ExpectedAppOutput.h>
#import <EyesImages/Eyes.h>
#import <EyesImages/EyesBase.h>
#import <EyesImages/EyesRunner.h>
#import <EyesImages/EyesScreenshot.h>
#import <EyesImages/FloatingMatchSettings.h>
#import <EyesImages/Image.h>
#import <EyesImages/ImageMatchSettings.h>
#import <EyesImages/ImagesCheckSettings.h>
#import <EyesImages/MatchLevel.h>
#import <EyesImages/MatchResult.h>
#import <EyesImages/MatchWindowData.h>
#import <EyesImages/Options.h>
#import <EyesImages/RectangleSize.h>
#import <EyesImages/Region.h>
#import <EyesImages/RegionProviderProtocol.h>
#import <EyesImages/RenderingInfo.h>
#import <EyesImages/RESTClient.h>
#import <EyesImages/RunningSession.h>
#import <EyesImages/ServerConnector.h>
#import <EyesImages/SessionResults.h>
#import <EyesImages/SessionStartInfo.h>
#import <EyesImages/SessionType.h>
#import <EyesImages/StartInfo.h>
#import <EyesImages/StartSessionProperty.h>
#import <EyesImages/Target.h>
#import <EyesImages/TestResults.h>
#import <EyesImages/TestResultContainer.h>
#import <EyesImages/TestResultsSummary.h>


