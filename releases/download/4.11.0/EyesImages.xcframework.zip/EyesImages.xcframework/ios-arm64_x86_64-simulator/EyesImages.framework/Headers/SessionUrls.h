// Licensed under the Applitools SDK License, which can be found here: https://www.applitools.com/eula/sdk

#import <Foundation/Foundation.h>

@interface SessionUrls : NSObject

@property (readonly, nonatomic) NSString *batch;
@property (readonly, nonatomic) NSString *session;

@end
