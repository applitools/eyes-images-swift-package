// Licensed under the Applitools SDK License, which can be found here: https://www.applitools.com/eula/sdk

#import "EyesBase.h"
#import "Region.h"
#import "CheckSettings.h"
#import "Configuration.h"

NS_ASSUME_NONNULL_BEGIN

@interface Eyes : EyesBase

@property (strong, nonatomic) Configuration *configuration;

/**
 Starts a test.
 @param appName The name of the application under test.
 @param testName The test name.
 */
- (void)openWithApplicationName:(nullable NSString *)appName testName:(nullable NSString *)testName;

/**
 Starts a test.
 @param appName The name of the application under test.
 @param testName The test name.
 @param viewportSize Determines the size used for the baseline. CGSizeZero will automatically grab the resolution from the image.
 */
- (void)openWithApplicationName:(nullable NSString *)appName testName:(nullable NSString *)testName viewportSize:(CGSize)viewportSize;

/**
 Matches the input image with the next expected image.
 @param image The image to perform visual validation for.
 @return Whether or not the image matched the baseline.
 */
- (BOOL)checkImage:(UIImage *)image;

/**
 Matches the input image with the next expected image.
 @param image The image to perform visual validation for.
 @param tag An optional tag to be associated with the validation checkpoint.
 @return Whether or not the image matched the baseline.
 */
- (BOOL)checkImage:(UIImage *)image tag:(nullable NSString *)tag;

/**
 Matches the input image with the next expected image.
 @param image The image to perform visual validation for.
 @param tag An optional tag to be associated with the validation checkpoint.
 @param ignoreMismatch YES if the server should ignore a negative result for the visual validation.
 @return Whether or not the image matched the baseline.
 */
- (BOOL)checkImage:(UIImage *)image tag:(nullable NSString *)tag ignoreMismatch:(BOOL)ignoreMismatch;

/**
 Perform visual validation for a region in a given image. Does not ignore mismatches.
 @param region The region to validate within the image.
 @param image The image to perform visual validation for.
 */
- (void)checkRegion:(Region *)region inImage:(UIImage *)image;

/**
 Perform visual validation for a region in a given image. Does not ignore mismatches.
 @param region The region to validate within the image.
 @param image The image to perform visual validation for.
 @param tag An optional tag to be associated with the validation checkpoint.
 */
- (void)checkRegion:(Region *)region inImage:(UIImage *)image tag:(nullable NSString *)tag;

@end


@interface Eyes (FluentInterface)

/**
 Perform visual validation for a region in a given image. Does not ignore mismatches.
 @param checkSettings The settings to use.
 @param tag An optional tag to be associated with the validation checkpoint.
 @return Whether or not the image matched the baseline.
 */
- (BOOL)checkWithTag:(nullable NSString *)tag andSettings:(id <CheckSettingsProtocol>)checkSettings;

@end

NS_ASSUME_NONNULL_END
