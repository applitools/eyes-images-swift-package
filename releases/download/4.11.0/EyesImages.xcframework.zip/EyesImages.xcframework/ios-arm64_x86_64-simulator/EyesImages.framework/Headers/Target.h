// Licensed under the Applitools SDK License, which can be found here: https://www.applitools.com/eula/sdk

#import "ImagesCheckSettings.h"

NS_ASSUME_NONNULL_BEGIN

@interface Target : NSObject

+ (ImagesCheckSettings *)image:(UIImage *)image;

@end

NS_ASSUME_NONNULL_END
