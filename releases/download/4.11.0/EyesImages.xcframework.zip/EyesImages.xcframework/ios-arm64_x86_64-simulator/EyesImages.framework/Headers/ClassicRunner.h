//
//  ClassicRunner.h
//  Applitools
//
//  Created by Anton Chuev on 23.09.2020.
//  Copyright © 2020 Applitools. All rights reserved.
//

#import "EyesRunner.h"

NS_ASSUME_NONNULL_BEGIN

@interface ClassicRunner : EyesRunner

@end

NS_ASSUME_NONNULL_END
