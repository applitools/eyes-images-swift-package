// Licensed under the Applitools SDK License, which can be found here: https://www.applitools.com/eula/sdk

#import <Foundation/Foundation.h>

@interface AppUrls : NSObject

@property (readonly, nonatomic) NSString *step;

@end
