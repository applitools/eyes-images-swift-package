// Licensed under the Applitools SDK License, which can be found here: https://www.applitools.com/eula/sdk

#import <Foundation/Foundation.h>

@interface Feature : NSObject <NSCopying>

+ (Feature *)AUTO_APP_NAME __attribute__((swift_name("Feature.AUTO_APP_NAME()")));

@end

