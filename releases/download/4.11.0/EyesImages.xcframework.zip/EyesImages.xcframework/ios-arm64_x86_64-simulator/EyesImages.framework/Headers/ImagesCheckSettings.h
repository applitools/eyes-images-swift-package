// Licensed under the Applitools SDK License, which can be found here: https://www.applitools.com/eula/sdk

#import "CheckSettings.h"
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol ImagesCheckTargetImageProtocol

- (UIImage *)targetImage;

@end

@interface ImagesCheckSettings : CheckSettings <ImagesCheckTargetImageProtocol>

- (instancetype)initWithTargetImage:(UIImage *)targetImage;
- (instancetype)region:(Region *)region;

@end

NS_ASSUME_NONNULL_END
