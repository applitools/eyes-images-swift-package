#!/bin/sh

#  extractChangeLog.sh
#  Applitools
#
#  Created by Anton Chuev on 05.05.2020.
#  Copyright © 2020 Applitools. All rights reserved.

awk -v ver="[$1]" '/^## \[/ { if (p) { exit}; if ($2 == ver) { p=1; next} } p && NF' "$2"
