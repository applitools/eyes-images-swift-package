#!/bin/sh

#  run_regression_tests.sh
#  Applitools
#
#  Created by Anton Chuev on 29.04.2020.
#  Copyright © 2020 Applitools. All rights reserved.

# Travis environment variables:
# - APPLITOOLS_API_KEY

# Default simulator name and iOS version
SIMULATOR_NAME="iPhone 11"
OS="13.5"

# Help function
Help()
{
   # Display Help
    echo "Script runs regression tests for all iOS SDKs: EyesXCUI and EyesImages."
    echo
    echo "Example: -n EyesXCUI -d iPhone\ 11 -o 13.5"
    echo "options:"
    echo "n                 SDK name"
    echo "s                 Scheme name"
    echo "d                 Simulator name. 'iPhone 11' by default."
    echo "o                 OS version. '13.5' by default."
    echo "h                 Print this Help."
    echo
}

# Get the options
while getopts "n:s:d:o:h" option; do
    case $option in
        n)
            SDK_NAME="$OPTARG" ;;
        s)
            SCHEME="$OPTARG" ;;
        d)
            SIMULATOR_NAME="$OPTARG" ;;
        o)
            OS="$OPTARG" ;;
        h)
            Help
            exit;;
        \?)
            echo "Error: Invalid option"
            exit;;
   esac
done

echo "Start running 'run_regression_tests' script for SDK ${SDK_NAME}, scheme: ${SCHEME}"

DESTINATION="platform=iOS Simulator,name=${SIMULATOR_NAME},OS=${OS}"
echo "DESTINATION = ${DESTINATION}"

# Generate batch id
BATCH_ID=$(uuidgen)
PLIST="ApplitoolsEyes/${SDK_NAME}Tests/Info.plist"

# Set apiKey, batchId and batchName to specific test target's Info.plist
/usr/libexec/PlistBuddy -c "Set :ApplitoolsApiKey '${APPLITOOLS_API_KEY}'" "${PLIST}"
/usr/libexec/PlistBuddy -c "Set :ApplitoolsBatchId '${BATCH_ID}'" "${PLIST}"
/usr/libexec/PlistBuddy -c "Set :ApplitoolsBatchName '${SDK_NAME} Regression'" "${PLIST}"

echo "Building and testing ${SDK_NAME}"
xcodebuild test \
-workspace ApplitoolsEyes/Applitools.xcworkspace \
-scheme "${SCHEME}" \
-sdk iphonesimulator \
-destination "${DESTINATION}"
